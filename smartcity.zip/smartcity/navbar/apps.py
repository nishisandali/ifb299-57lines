from django.apps import AppConfig


class NavbarConfig(AppConfig):
    name = 'navbar'
